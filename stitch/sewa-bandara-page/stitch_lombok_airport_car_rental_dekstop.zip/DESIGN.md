---
name: Sasak Transfer System
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#44474e'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#74777f'
  outline-variant: '#c4c6cf'
  surface-tint: '#485f83'
  primary: '#001835'
  on-primary: '#ffffff'
  primary-container: '#132d4e'
  on-primary-container: '#7d95bc'
  inverse-primary: '#b0c8f1'
  secondary: '#a63c00'
  on-secondary: '#ffffff'
  secondary-container: '#fd6003'
  on-secondary-container: '#521900'
  tertiary: '#281300'
  on-tertiary: '#ffffff'
  tertiary-container: '#452500'
  on-tertiary-container: '#d77f00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d5e3ff'
  primary-fixed-dim: '#b0c8f1'
  on-primary-fixed: '#001c3b'
  on-primary-fixed-variant: '#30486a'
  secondary-fixed: '#ffdbce'
  secondary-fixed-dim: '#ffb598'
  on-secondary-fixed: '#370e00'
  on-secondary-fixed-variant: '#7e2c00'
  tertiary-fixed: '#ffdcbe'
  tertiary-fixed-dim: '#ffb871'
  on-tertiary-fixed: '#2d1600'
  on-tertiary-fixed-variant: '#6a3c00'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  margin: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system serves a modern, premium airport transit and car rental service based in Lombok, Indonesia. The identity combines operational reliability with tropical warmth, communicating punctual 24 hour service, transparency, and effortless booking.

### Core Principles
- **Clarity and Dependability:** Interfaces prioritize speed of comprehension. Travelers booking an airport pickup often navigate high stress contexts (delayed flights, baggage claims, unfamiliar terminals). Visual hierarchies must be unambiguous.
- **Pure Flat Modernism:** Visual distinction is achieved without skeuomorphism, drop shadows, or gradient fills. Depth relies entirely on structured surface colors, strict white space, and refined 1px borders.
- **Tropical Hospitality:** The palette captures both maritime transit stability and energetic island sunrise hues, balanced by functional whites and soft slates.

### Form Factor and Text Guidelines
- Eliminate hyphen punctuation in UI strings, dates, phone previews, and breadcrumbs. Use slashes, bullets, or direct spacing instead.
- Retain high visual breathing room around all transaction points: vehicle selection, driver details, flight number inputs, and rate cards.

## Colors

The palette employs a purposeful separation between operational hierarchy, conversion triggers, and immediate direct communication.

### Palette Definitions
- **Deep Navy (`#132D4E`):** Primary brand anchor. Used for primary navigation headers, main value statements, authoritative titles, and structural frames. Communicates safety, fleet reliability, and 24 hour operations.
- **Vibrant Orange (`#FC5F02`):** Primary action color. Applied to reservation buttons, pricing highlights, active booking steps, and critical status badges.
- **Warm Amber (`#F5951C`):** Secondary accent. Used for ratings, vehicle tier badges (e.g. VIP, Family, Group), and secondary promotions.
- **Direct Action Green (`#25D366`):** Dedicated exclusively to direct messaging and instant driver coordination via WhatsApp. Never used for general system success messages.
- **Canvas White (`#FFFFFF`):** Base container fill for interactive cards, input fields, and modular panels.
- **Warm Gray Canvas (`#F8F9FA`):** Page surface background, distinguishing card panels without requiring heavy borders or dropshadows.
- **Charcoal Text (`#1A202C`):** Primary typographic tone for highest contrast accessibility on white and light gray backgrounds.
- **Muted Slate (`#4A5568`):** Subheadings, technical vehicle specs, labels, and secondary details.
- **Structural Border (`#E2E8F0`):** Pure 1px flat structural line for dividing components and defining card perimeters.

### Functional Roles
- Avoid blending or fading these tones. Each block of color must be solid, crisp, and clearly delimited.
- Interactive elements must retain full contrast against `#F8F9FA` and `#FFFFFF`.

## Typography

The typographic pairing balances modern commercial clarity with high functional performance under varying outdoor lighting conditions.

- **Headline & Display Font (Plus Jakarta Sans):** Brings contemporary warmth and geometric authority to vehicle headers, destination titles, and section markers.
- **Body Font (Inter):** Ensures legible reading across dense lists of rental inclusions, baggage capacity specs, airport terminal instructions, and policy details.
- **Formatting Directives:** Strict avoidance of hyphen symbols (`-`) across all typography rules. Date ranges should use en-spaces or slashes (e.g. `24 Oct to 26 Oct` or `24/10/2025`). Distance labels should format as `45 km` rather than hyphenated compounds. Flight input masks must rely on natural character spacing instead of dashed separators.

## Layout & Spacing

This design system uses a responsive fluid grid tied to an 8px base rhythm. Layouts must emphasize openness, clean separation, and uncrowded interaction zones.

### Grid Framework
- **Desktop (1200px and up):** 12 column fluid layout, maximum container width 1240px, 24px (`1.5rem`) gutters, 32px margins.
- **Tablet (768px to 1199px):** 8 column fluid layout, 20px gutters, 24px margins.
- **Mobile (320px to 767px):** 4 column layout, 16px gutters, 16px margins. Full width stacking for fleet selection cards and booking summaries.

### Structural Flow
- Sections alternate deliberately between `#F8F9FA` and `#FFFFFF` backdrops to structure content blocks without introducing horizontal rules or deep box shadows.
- Micro component spacing uses `space-xs` (4px) and `space-sm` (8px) for badge text, ratings, and vehicle luggage icons. Content groupings inside cards strictly utilize `space-md` (16px) and `space-lg` (24px).

## Elevation & Depth

This design system rejects blur based shadows, drop shadows, and visual skeuomorphism in favor of pure flat planes and crisp linear borders.

### Depth by Containment and Surface Tiers
- **Canvas Base:** `#F8F9FA` acts as the low tier floor for search filters and catalog layouts.
- **Primary Cards and Panels:** Stand out through flat `#FFFFFF` solid fill bounded by a crisp `1px solid #E2E8F0` border.
- **Active and Selected States:** An active card (e.g., chosen vehicle or pickup time) does not rise or cast a shadow. Instead, its border switches from `#E2E8F0` to `2px solid #FC5F02` with an optional `#FC5F02` tint badge.
- **Floating Overlays and Drawers:** Modals, mobile bottom sheets for flight pickup selection, and sticky action bars use clean `#FFFFFF` with a deliberate top or perimeter border of `1px solid #E2E8F0`. When dimming is required behind modals, a flat neutral scrim (`#132D4E` at 30% opacity) is used without blur.

## Shapes

The design uses a clean, controlled corner geometry that avoids overly round or pill forms for primary containers, maintaining a disciplined modern architecture.

- **Base Radius (`0.5rem` / 8px):** Applied to form fields, primary buttons, vehicle feature tags, and standard interactive tiles.
- **Container Radius (`1rem` / 16px):** Applied to fleet display cards, airport zone maps, itinerary outlines, and booking review summaries.
- **Large Structural Radius (`1.5rem` / 24px):** Reserved for hero banner containment and airport terminal pickup guides.
- **Circular Elements:** Strictly reserved for driver profile avatars, numeric itinerary step counters, and WhatsApp icon floating triggers.

## Components

### Buttons
- **Primary CTA:** Background `#FC5F02`, text `#FFFFFF`, font weight 600, corner radius 8px, padding 12px 24px. Hover state changes background to `#E05300`. Flat, no shadow.
- **Direct Connect CTA (WhatsApp):** Background `#25D366`, text `#FFFFFF`, font weight 600, corner radius 8px, paired with official monoline chat icon. Hover state darkens to `#1EBE5D`.
- **Secondary CTA:** Background `#132D4E`, text `#FFFFFF`, corner radius 8px. Hover state changes to `#0E2139`.
- **Ghost/Outline Button:** Background transparent, border `1px solid #132D4E`, text `#132D4E`. Hover fills with `#F8F9FA`.

### Input Fields & Selectors
- **Default State:** Background `#FFFFFF`, border `1px solid #E2E8F0`, padding 12px 16px, corner radius 8px, text `#1A202C`. Placeholder text `#4A5568`.
- **Focus State:** Border changes to `1px solid #132D4E` with a crisp outer outline of `2px solid #E2E8F0`.
- **Special Airport Inputs (Flight Number, Landing Time):** Prefixed with flat navy icons. Hyphen characters are strictly disallowed in display masks; format flight codes with clean spaces (e.g. `GA 432` or `JT 650`).

### Cards & Fleet Display
- **Vehicle Card:** White surface, `1px solid #E2E8F0` border, 16px corner radius, internal padding of 20px. Contains vehicle photo against a neutral background, vehicle class tag, passenger capacity, baggage allowance, and transmission type.
- **Price Block:** Aligned bottom right inside card. Bold display in `#FC5F02`, subtitle in `#4A5568` indicating `All in / 24 Jam`.
- **Selected Vehicle:** The perimeter border transforms to `2px solid #FC5F02` without changing layout dimensions.

### Chips & Badges
- **Transmission / Luggage Chips:** Background `#F8F9FA`, border `1px solid #E2E8F0`, text `#1A202C`, font size 12px, font weight 600, radius 6px, padding 4px 10px.
- **Service Status Badge (24 Jam Antar Jemput):** Solid `#132D4E` background with `#FFFFFF` text or soft `#FFF4ED` background with `#FC5F02` text.

### Selection Controls (Checkboxes & Radios)
- **Checkboxes:** 20px by 20px, 4px border radius. Unchecked: `1px solid #CBD5E1` on white. Checked: `#FC5F02` solid fill with white checkmark.
- **Radio Buttons:** 20px round. Unchecked: `1px solid #CBD5E1`. Selected: solid `#132D4E` outer border with a centered 10px `#132D4E` solid circle.

### Airport Specific Components
- **Terminal Pickup Indicator:** A structured 2 column block detailing Terminal Kedatangan (Arrival) vs Area Parkir VIP pickup points. Pure monoline flight and pin icons, zero gradients.
- **Driver Status Card:** Clean white card featuring driver photo, verified identity badge in `#132D4E`, vehicle plate number in monospace font, and a full width `#25D366` direct chat trigger.